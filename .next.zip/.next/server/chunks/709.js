exports.id = 709;
exports.ids = [709];
exports.modules = {

/***/ 3573:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Header)
/* harmony export */ });
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5675);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var _public_img_logo_png__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4253);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);




function Header() {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
    className: "flex items-center justify-center flex-col mt-6",
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
      href: "/",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("a", {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_image__WEBPACK_IMPORTED_MODULE_0__.default, {
          src: _public_img_logo_png__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z,
          alt: "Presidencia",
          width: 60,
          height: 60
        })
      })
    })
  });
}

/***/ }),

/***/ 8538:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2364);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_seo__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);





const Layout = ({
  children,
  title,
  canonical,
  description
}) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("main", {
  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(next_seo__WEBPACK_IMPORTED_MODULE_1__.NextSeo, {
    title: title,
    description: description,
    canonical: canonical,
    openGraph: {
      title,
      description
    }
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
    children: children
  })]
});

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Layout);

/***/ }),

/***/ 9537:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Menu)
});

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./public/img/logo.png
var logo = __webpack_require__(4253);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/components/Menu/LinkMenu.js





function LinkMenu(props) {
  return /*#__PURE__*/jsx_runtime_.jsx("li", {
    className: "mt-1",
    children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
      href: `${props.link}`,
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
        className: "py-2 md:py-3",
        children: [/*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
          src: logo/* default */.Z,
          width: 15,
          height: 15
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
          className: "text-xs md:text-xl ml-2 opacity-80",
          children: [" ", props.title, " "]
        })]
      })
    })
  });
}
;// CONCATENATED MODULE: ./src/components/Menu/Menu.js





function Menu() {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "max-w-screen-lg xl:max-w-screen-xl container mx-auto px-4 menuContent z-50",
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "flex items-center justify-center flex-col",
      children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
        src: logo/* default */.Z,
        alt: "Presidencia",
        width: 60,
        height: 60
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("h2", {
      className: "mt-2 text-xl md:text-5xl font-semibold text-textcolor mb-6 leading-tight",
      children: [" Jorge Carlos Fonseca: O Presidente ", /*#__PURE__*/jsx_runtime_.jsx("br", {}), " junto das Comunidades "]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
      children: [/*#__PURE__*/jsx_runtime_.jsx(LinkMenu, {
        title: "Introdu\xE7\xE3o",
        link: "/introducao"
      }), /*#__PURE__*/jsx_runtime_.jsx(LinkMenu, {
        title: "As Comunidades Cabo-verdianas no Exterior",
        link: "/exterior"
      }), /*#__PURE__*/jsx_runtime_.jsx(LinkMenu, {
        title: "O Presidente da Rep\xFAblica e as Comunidades Cabo-verdianas no Exterior",
        link: "comunidade"
      }), /*#__PURE__*/jsx_runtime_.jsx(LinkMenu, {
        title: "Visitas \xE0s Comunidades radicadas em \xC1frica",
        link: "/comunidade-africa"
      }), /*#__PURE__*/jsx_runtime_.jsx(LinkMenu, {
        title: "Visitas \xE0s Comunidades radicadas na Europa",
        link: "/comunidade-europa"
      }), /*#__PURE__*/jsx_runtime_.jsx(LinkMenu, {
        title: "Visitas \xE0s Comunidades radicadas nos Estados Unidos da America e resto do mundo",
        link: "comunidade-mundo"
      }), /*#__PURE__*/jsx_runtime_.jsx(LinkMenu, {
        title: "Condecora\xE7\xF5es",
        link: "/condecoracoes"
      }), /*#__PURE__*/jsx_runtime_.jsx(LinkMenu, {
        title: "Cita\xE7\xF5es",
        link: "/citacoes"
      }), /*#__PURE__*/jsx_runtime_.jsx(LinkMenu, {
        title: "Galeria de Fotos",
        link: "/galeria"
      })]
    })]
  });
}

/***/ }),

/***/ 4253:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/image/public/img/logo.a2c1b0ddcc79747f566ddc5035be1af6.png","height":60,"width":60,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABAUlEQVR42mNgYFjAyAAG3cZTustWzJ5QvpKBb6IJAxgsYmT4/5+Btby6MXbJ2r3/r129+v/q1Sv/F6zc9b+ytiUOJMdwaQWD0uS56+89ffLk//2HT37ee/Dk5/Pnz/4DxR5cWM6gzDCv2cFmw7aDX96/e/1/3ood/+av3Pnvw7s3/9du3v9lXoubLcPs6VJibROXX9uy++j/dduP/ABhELttwrIb82YaijMwTFHxD65qyUwvm/p/0tx1YJwGZIdWt2YxTFH2Y1Dud9NlmGYUUdjeb5PXOK8ZhAvbJ9iAxIByegxg0BAlsH8Dg9yDTQzOd9YzuO5cw6DA0BQpwMDAwAAAxe+D6MB1jLoAAAAASUVORK5CYII="});

/***/ }),

/***/ 2431:
/***/ (() => {

/* (ignored) */

/***/ })

};
;