"use strict";
exports.id = 140;
exports.ids = [140];
exports.modules = {

/***/ 1140:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Footer)
});

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./public/img/gallery.svg
/* harmony default export */ const gallery = ({"src":"/_next/static/image/public/img/gallery.3250946a4d7548fcc888e8dfba092a76.svg","height":26,"width":26});
;// CONCATENATED MODULE: ./public/img/right.svg
/* harmony default export */ const right = ({"src":"/_next/static/image/public/img/right.1e7203f5ca2c4f8c835715608d768a21.svg","height":27,"width":44});
;// CONCATENATED MODULE: ./public/img/left.svg
/* harmony default export */ const left = ({"src":"/_next/static/image/public/img/left.a55785dbd710d0319092ff5bf2fe1d3f.svg","height":39,"width":43});
// EXTERNAL MODULE: ./src/components/Menu/Menu.js + 1 modules
var Menu = __webpack_require__(9537);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/components/Main/Footer.js








function Footer(props) {
  return /*#__PURE__*/jsx_runtime_.jsx("footer", {
    className: "fixed bottom-0 left-0 right-0 w-full px-10 bg-gbsite",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex items-center flex-row justify-around py-4 ",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "md:flex hidden",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "mr-5",
          children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: `${props.link1}`,
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
              children: [" ", /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                src: left,
                width: 25,
                height: 25
              }), " "]
            })
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: `${props.link1}`,
          children: props.title1
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "hidden md:block",
        children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: `${props.link2}`,
          children: props.title2
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "hidden md:block",
        children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: `${props.link3}`,
          children: props.title3
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: "/galeria",
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
              src: gallery,
              width: 25,
              height: 25
            })
          })
        })
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "mr-4 flex text-textcolor font-bold text-xl",
        children: [/*#__PURE__*/jsx_runtime_.jsx("input", {
          type: "checkbox",
          id: "menuToggle"
        }), /*#__PURE__*/jsx_runtime_.jsx("label", {
          for: "menuToggle",
          className: "menuOpen",
          children: /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "open"
          })
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "menu menuEffects",
          children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
            for: "menuToggle"
          }), /*#__PURE__*/jsx_runtime_.jsx(Menu/* default */.Z, {})]
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "ml-5",
          children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: `${props.link3}`,
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
              children: [" ", /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                src: right,
                width: 25,
                height: 25
              }), " "]
            })
          })
        })]
      })]
    })
  });
}

/***/ })

};
;